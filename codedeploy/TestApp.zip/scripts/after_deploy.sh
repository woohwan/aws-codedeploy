#!/bin/bash  
cd /opt/tomcat/bin/
# sudo systemctl stop tomcat
# sudo systemctl start tomcat