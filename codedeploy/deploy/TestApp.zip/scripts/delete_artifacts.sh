#!/bin/bash  
cd /home/ec2-user/deployed
rm -rf *