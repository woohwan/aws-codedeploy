#!/bin/bash
cd /opt/tomcat/webapps
rm -rf validate.war validate